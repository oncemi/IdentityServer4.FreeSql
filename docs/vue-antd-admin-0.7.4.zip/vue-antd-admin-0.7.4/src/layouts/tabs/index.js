import TabsView from './TabsView'
export default TabsView
