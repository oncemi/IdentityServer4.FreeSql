import AdvancedForm from '@/pages/form/advance/AdvancedForm'
export default AdvancedForm
