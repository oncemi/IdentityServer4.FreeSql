import WorkPlace from './WorkPlace'
export default WorkPlace
