export default {
  updated() {
    this.$page.alert.top = 100
  }
}
